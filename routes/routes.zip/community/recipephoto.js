const express = require('express');
const aws = require('aws-sdk');
const async = require('async');
const router = express.Router();
const jwt = require('jsonwebtoken');
const moment = require('moment');
aws.config.loadFromPath('./config/aws_config.json');
const pool = require('../../config/db_pool');

router.get('/populity', function(req, res){
  let task_array = [
    //1. connection 설정
    function(callback){
			pool.getConnection(function(err, connection){
				if(err){
          res.status(500).send({
            msg : "500 Connection error"
          });
          callback("getConnecntion error at login: " + err, null);
        }
				else callback(null, connection);
			});
		},
    //2. header의 token 값으로 user_email 받아옴.
    function(connection, callback){
      let token = req.headers.token;
      jwt.verify(token, req.app.get('jwt-secret'), function(err, decoded){
        if(err){
          res.status(501).send({
            msg : "501 user authorization error"
          });
          connection.release();
          callback("JWT decoded err : "+ err, null);
        }
        else callback(null, decoded.user_email, connection);
      });
    },
    //메인에서 메거진 항목으로 보일 6개를 불러옴
    function(useremail,connection,callback){
      let query = 'select * from my_recipe order by myrecipe_count desc limit 6';
      connection.query(query,function(err,myrecipeData){
        if(err){
            res.status(501).send({
              msg : "query err"
            });
            connection.release();
            callback("query err : "+ err, null);
        }
        else{
        let finaldata=[];
        for(let i = 0 ; i < myrecipeData.length ; i++){
          let data = {
              id : myrecipeData[i].myrecipe_id,
              imageUrl : myrecipeData[i].myrecipe_image_url,
              title : myrecipeData[i].myrecipe_title,
              checkSaveList : false
            };
                     finaldata.push(data);
                }
         callback(null,finaldata,useremail,connection);
       }
      });
    },
    function(datalist,useremail,connection,callback){
      let query = 'select my_savelist_origin_id from my_savelist where user_email = ? and my_savelist_from = 2';
      connection.query(query, useremail, function(err, saveddata){
        if(err){
          res.status(501).send({
            msg : "savelist query err"
          });
          connection.release();
          callback("query err : "+err,null);
        }
        else{
          callback(null,saveddata,datalist,useremail,connection);
        }
      });
    },
    function(saveddata,datalist,useremail,connection,callback){
      let count = 0;
      async.whilst(
        function(){
          return count < datalist.length;
        },
        function(loop){
          for(let i = 0 ; i < saveddata.length; i++){
            if(datalist[count].id == saveddata[i].my_savelist_origin_id){
              datalist[count].checkSaveList = true;
            }
          }
          count++;
          loop(null);
        },
        function(err){
          callback(null,datalist,connection);
        }
      );
    },
    //데이터 가공

    //가공한데이터 클라에게 전송
    function(myrefinaldata, connection, callback){
      res.status(201).send({
        msg : "ok",
        data : myrefinaldata
      });
      callback(null,connection);
    },

    //커넥션 해제
    function(connection, callback){
        connection.release();
      callback(null,"o~~~~k");
    }



  ];

  async.waterfall(task_array, function(err, result){
    if(err){
      console.log(err);
    }
    else console.log(result);
  });
 });

 router.get('/newest', function(req, res){
   let task_array = [
     //1. connection 설정
     function(callback){
      console.log("11");
 			pool.getConnection(function(err, connection){
 				if(err){
           res.status(500).send({
             msg : "500 Connection error"
           });
           callback("getConnecntion error at login: " + err, null);
         }
 				else callback(null, connection);
 			});
 		},
     //2. header의 token 값으로 user_email 받아옴.
     function(connection, callback){
       console.log("22");
       let token = req.headers.token;
       jwt.verify(token, req.app.get('jwt-secret'), function(err, decoded){
         if(err){
           res.status(501).send({
             msg : "501 user authorization error"
           });
           connection.release();
           callback("JWT decoded err : "+ err, null);
         }
         else callback(null, decoded.user_email, connection);
       });
     },
     //메인에서 메거진 항목으로 보일 6개를 불러옴
     function(useremail,connection,callback){
       console.log("33");
       let query = 'select * from my_recipe'+' order by myrecipe_post_time desc'+' limit 6';
       connection.query(query,function(err,myrecipeData){
         if(err){
             res.status(501).send({
               msg : "query err"
             });
             connection.release();
             callback("query err : "+ err, null);
         }
         else{
         let finaldata=[];
         for(let i = 0 ; i < myrecipeData.length ; i++){
           let data = {
               id : myrecipeData[i].myrecipe_id,
               imageUrl : myrecipeData[i].myrecipe_image_url,
               title : myrecipeData[i].myrecipe_title,
               checkSaveList : false
             };
                      finaldata.push(data);
                 }
          callback(null,finaldata,useremail,connection);
        }
       });
     },
     //데이터 가공
     function(datalist,useremail,connection,callback){
       let query = 'select my_savelist_origin_id from my_savelist where user_email = ? and my_savelist_from = 2';
       connection.query(query, useremail, function(err, saveddata){
         if(err){
           res.status(501).send({
             msg : "savelist query err"
           });
           connection.release();
           callback("query err : "+err,null);
         }
         else{
           callback(null,saveddata,datalist,useremail,connection);
         }
       });
     },
     function(saveddata,datalist,useremail,connection,callback){
       let count = 0;
       async.whilst(
         function(){
           return count < datalist.length;
         },
         function(loop){
           for(let i = 0 ; i < saveddata.length; i++){
             if(datalist[count].id == saveddata[i].my_savelist_origin_id){
               datalist[count].checkSaveList = true;
             }
           }
           count++;
           loop(null);
         },
         function(err){
           callback(null,datalist,connection);
         }
       );
     },
     //가공한데이터 클라에게 전송
     function(myrefinaldata, connection, callback){
       console.log("44");
       res.status(201).send({
         msg : "ok",
         data : myrefinaldata
       });
       callback(null,connection);
     },

     //커넥션 해제
     function(connection, callback){
       console.log("55");
         connection.release();
       callback(null,"o~~~~k");
     }



   ];

   async.waterfall(task_array, function(err, result){
     if(err){
       console.log(err);
     }
     else console.log(result);
   });
  });

  module.exports = router;
